How to use it?

First window: 
	1. set the time interval;
	2. set today's goal
	3. choose a music file (mp3 format)
	4. click "start to work" big button

Then after the time minutes you typed in the first window, the window will jumps out again and play the music at the same time.
you can do three thing on this window:
	1. take note what you have done
	2. change to another the music file to play (mp3 format)
	3. change the the length of time interval.

The program will automatically record the progress in the "notes" folder. Each day, the program will only generate one record file.

Author note:
This small tool is aimed to break working time into time intervals and help user to record each interval's work.

Because I used JLayer to play the mp3 file, which is licenced under LGPL, so this program is also licenced under LGPL.

Please contact me if any question or improvement for this program is necessary for me to know.

My email is: zjcxgaoxing@gmail.com

Tianxiang Gao
2016.9.10
Ames, Iowa.


    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
